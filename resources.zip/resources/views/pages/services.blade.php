@extends('layout.master')
@section('title','services')
@section('content')
    <div class="jumbotron text-center m-2 ">
        <div class="row justify-content-md-center">
            <div class="col-6">
                <h1>Services</h1>
                <p>this is services page</p>
                <h2>Our Services :</h2>
                <ol class='list-group'>
                @foreach ($data['services'] as $item)
                    <li class="list-group-item"> {{$item}} </li>
                @endforeach
                </ol> 
            </div>
        </div>
        
              
    </div>
     
    
@endsection
        
