@extends('layout.master')

@section('content')
    <h1>Posts</h1>
    <ul class="list-group">
        @foreach ($posts as $item)
        
        <li class="list-group-item">{{$item->title}}<br>{{$item->body}}<br><small>Written on: {{$item->created_at}}</small></li>

        @endforeach  
    </ul>
   
@endsection
